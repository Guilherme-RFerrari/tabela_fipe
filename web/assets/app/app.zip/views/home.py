import flet as ft
import locale
from components.component import appBar, bottomAppBar
from controllers.controller import request_Marca, request_Modelo, request_Fipe

locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


def homeView(page):

    def coleta_Marca(e):
        dropMarca.options.clear()
        tableModelo.rows.clear()
        tableFipe.rows.clear()
        textModelo.value = f""
        textReferencia.value = f""
        dropMarca.disabled=True
        page.update()
        for marca in request_Marca(dropTipoVeiculo.value):
            dropMarca.options.append(ft.dropdown.Option(text=marca['brand'], key=marca['id']))
        dropMarca.disabled=False
        page.update()
        
    def coleta_Modelos(e):
        tableModelo.rows.clear()
        tableFipe.rows.clear()
        textModelo.value = f""
        textReferencia.value = f""
        tableModelo.disabled=True
        page.update()
        for modelo in request_Modelo(dropMarca.value):
            tableModelo.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(content=ft.Text(value=modelo['model'], size=13, italic=True, weight=ft.FontWeight.W_600)),
                        ft.DataCell(content=ft.Text(value=modelo['years'], size=11, italic=True)),
                    ],
                    data=[modelo['model'], modelo['years'], modelo['fipe_code']],
                    on_select_changed=coleta_Fipe
                )
            ),
        tableModelo.disabled=False
        page.update()
        
    def coleta_Fipe(e):
        tableFipe.rows.clear()
        modelo_fipe = request_Fipe(e.control.data[2])
        for ano in modelo_fipe['years']:
            tableFipe.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(content=ft.Text(value=ano['model_year'], size=13, italic=True, weight=ft.FontWeight.W_600)),
                        ft.DataCell(content=ft.Text(value=ano['fuel'], size=13, italic=True)),
                        ft.DataCell(content=ft.Text(value=locale.currency(ano['price'], grouping=True), size=13, italic=True)),
                    ],
                )
            )
        textModelo.value = f"{modelo_fipe['brand']} - {modelo_fipe['model']}"
        textReferencia.value = f"{modelo_fipe['reference'].upper()}"
        page.update()
    
    
    
    
    
    dropTipoVeiculo = ft.Dropdown(
        padding=ft.padding.all(10),
        width=500,
        label="Tipo de Veículo",
        on_change=coleta_Marca,
        options=[
            ft.dropdown.Option(text="Carro", key="1"), 
            ft.dropdown.Option(text="Moto", key="2"), 
            ft.dropdown.Option(text="Caminhão", key="3")
            ],
    )
    
    dropMarca = ft.Dropdown(
        padding=ft.padding.all(10),
        width=500,
        label="Selecione a Marca", 
        on_change=coleta_Modelos
    )
    
    tableModelo = ft.DataTable(
        data_row_max_height=60,
        data_row_min_height=60,
        columns=[
            ft.DataColumn(
                label=ft.Text(
                    value="Modelo", 
                    size=17, 
                    weight=ft.FontWeight.W_700, 
                    color=ft.Colors.SECONDARY
                ), 
                heading_row_alignment=ft.MainAxisAlignment.START
            ),
            ft.DataColumn(
                label=ft.Text(
                    value="Ano", 
                    size=17, 
                    weight=ft.FontWeight.W_700, 
                    color=ft.Colors.SECONDARY
                ), 
                heading_row_alignment=ft.MainAxisAlignment.START
            ),
        ],
        rows=[
        ],
    )

    tableFipe = ft.DataTable(
        columns=[
            ft.DataColumn(label=ft.Text("Ano"), heading_row_alignment=ft.MainAxisAlignment.START),
            ft.DataColumn(label=ft.Text("Combustivel"), heading_row_alignment=ft.MainAxisAlignment.START),
            ft.DataColumn(label=ft.Text("R$"), heading_row_alignment=ft.MainAxisAlignment.START),
        ],
        rows=[
        ],
    )

    textReferencia = ft.Text(
        value=f"", 
        size=14, 
        weight=ft.FontWeight.W_300, 
        color=ft.Colors.TERTIARY, 
        text_align=ft.TextAlign.CENTER
    )
    
    textModelo = ft.Text(
        value=f"", 
        size=14, 
        weight=ft.FontWeight.W_300, 
        color=ft.Colors.TERTIARY, 
        text_align=ft.TextAlign.CENTER
    )

    return ft.View(
        route="/",
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        vertical_alignment=ft.MainAxisAlignment.CENTER,
        scroll=ft.ScrollMode.ADAPTIVE,
        adaptive=True,
        spacing=50,
        padding=ft.padding.all(0),
        controls=[
            appBar(),
            ft.Column(
                width=500,
                spacing=30,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                adaptive=True,
                controls=[
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                        dropTipoVeiculo
                        ]
                    ),
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            dropMarca
                        ]
                    ),
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                        
                        ]
                    ),
                    ft.Container(
                        border_radius=10,
                        border=ft.border.all(1, ft.Colors.OUTLINE),
                        height=400,
                        margin=ft.margin.only(left=8, right=8),
                        #padding=ft.padding.only(left=15, right=15),
                        content=ft.ListView(
                            adaptive=True,
                            controls=[tableModelo],
                        ),
                    ),
                    ft.Divider(
                        height=9, 
                        thickness=3,
                        
                    ),
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            ft.Text(
                                value=f"Referência", 
                                size=22, 
                                weight=ft.FontWeight.W_600, 
                                color=ft.Colors.PRIMARY, 
                                text_align=ft.TextAlign.CENTER)      
                        ]  
                    ),
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            textReferencia
                        ]  
                    ),
                    ft.ResponsiveRow(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            textModelo
                        ]  
                    ),
                    ft.Container(
                        border_radius=10,
                        border=ft.border.all(1, ft.Colors.OUTLINE),
                        height=300,
                        margin=ft.margin.only(left=8, right=8),
                        #padding=ft.padding.only(left=15, right=15),
                        content=ft.ListView(
                            adaptive=True,
                            controls=[tableFipe]
                        ),
                    ),
                ]
            ),
            bottomAppBar()
        ],
    )