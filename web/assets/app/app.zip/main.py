import flet as ft
from views.home import homeView

def main(page: ft.Page):
    page.title="Tabela Fipe"
    page.theme=ft.Theme()

    def route_change(route):
        page.views.clear()
        page.views.append(
            homeView(page)
        )
        page.update()
    

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)


    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)


ft.app(main, view=ft.AppView.WEB_BROWSER)