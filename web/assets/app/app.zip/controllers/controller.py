import os
import requests
import flet as ft
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("API_KEY")

def request_Marca(tipo_veiculo):
    response = requests.get(f"https://api.invertexto.com/v1/fipe/brands/{tipo_veiculo}?token={api_key}")
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Erro: {response.status_code}")
        
def request_Modelo(id_marca):
    response = requests.get(f"https://api.invertexto.com/v1/fipe/models/{id_marca}?token={api_key}")
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Erro: {response.status_code}")
        
def request_Fipe(fipe_code):
    response = requests.get(f"https://api.invertexto.com/v1/fipe/years/{fipe_code}?token={api_key}")
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Erro: {response.status_code}")