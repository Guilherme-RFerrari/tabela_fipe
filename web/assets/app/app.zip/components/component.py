import flet as ft

def appBar():
    return ft.AppBar(title=ft.Text("Consulta Tabela Fipe"), bgcolor=ft.Colors.PRIMARY_CONTAINER)

def bottomAppBar():
    return ft.ResponsiveRow(
        height=80,
        spacing=0,
        controls=[
            ft.Container(
                bgcolor=ft.Colors.PRIMARY_CONTAINER,
                content=ft.Column(
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    height=80,
                    controls=[
                        ft.ResponsiveRow(
                            alignment=ft.MainAxisAlignment.CENTER,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Text(value="Guilherme Ribeiro Ferrari ©", text_align=ft.TextAlign.CENTER, italic=True, weight=ft.FontWeight.W_500, size=10)        
                            ]
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.TextButton(
                                    width=30,
                                    height=30,
                                    style=ft.ButtonStyle(padding=0),
                                    url="https://www.instagram.com/guitteferrari/",
                                    content=ft.Image(
                                        src="https://cdn-icons-png.flaticon.com/512/1384/1384031.png",
                                        width=25,
                                        height=25,
                                        fit=ft.ImageFit.CONTAIN,
                                    )
                                ),
                                ft.TextButton(
                                    width=30,
                                    height=30,
                                    style=ft.ButtonStyle(padding=0),
                                    url="https://www.facebook.com/Guilherme.Ribeiro132",
                                    content=ft.Image(
                                        src="https://cdn-icons-png.flaticon.com/512/21/21155.png",
                                        width=25,
                                        height=25,
                                        fit=ft.ImageFit.CONTAIN,
                                    )
                                ),
                                ft.TextButton(
                                    width=30,
                                    height=30,
                                    style=ft.ButtonStyle(padding=0),
                                    url="https://www.linkedin.com/in/guilherme-ribeiro-ferrari/",
                                    content=ft.Image(
                                        src="https://cdn-icons-png.flaticon.com/512/61/61109.png ",
                                        width=25,
                                        height=25,
                                        fit=ft.ImageFit.CONTAIN,
                                    )
                                )      
                            ]
                        ),
                        
                    ]
                )
            )
        ]
    )